import { useRef, useCallback, useEffect } from 'react';
import { getSocket, sendOffer, sendAnswer, sendIceCandidate } from '../services/socket';
import { useMeetingStore } from '../stores/useMeetingStore';

const ICE_SERVERS: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    // TURN server — used when STUN fails (e.g. symmetric NAT)
    // Coturn is at www.emai2.cn:3478 (direct, no nginx proxy needed for TURN)
    {
      urls: 'turn:www.emai2.cn:3478',
      username: 'screenflow',
      credential: 'screenflow-turn-2024',
    },
  ],
};

export function useWebRTC(localStream: MediaStream | null) {
  const peersRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const { setRemoteStream, removeRemoteStream } = useMeetingStore();
  const currentUserIdRef = useRef<string>('');

  // Update currentUserIdRef when room-joined is received
  useEffect(() => {
    const socket = getSocket();
    const handler = (data: { userId: string }) => {
      currentUserIdRef.current = data.userId;
    };
    socket.on('room-joined', handler);
    return () => socket.off('room-joined', handler);
  }, []);

  const createPeerConnection = useCallback(
    (remoteUserId: string): RTCPeerConnection => {
      const pc = new RTCPeerConnection(ICE_SERVERS);

      // Add local tracks
      if (localStream) {
        localStream.getTracks().forEach((track) => {
          pc.addTrack(track, localStream);
        });
      }

      // Handle incoming remote stream
      pc.ontrack = (event) => {
        if (event.streams[0]) {
          setRemoteStream(remoteUserId, event.streams[0]);
        }
      };

      // Send ICE candidates to remote peer
      pc.onicecandidate = (event) => {
        if (event.candidate) {
          console.log('[WebRTC] ICE candidate generated for', remoteUserId, ':', event.candidate.type, event.candidate.protocol);
          sendIceCandidate(remoteUserId, event.candidate.toJSON());
        } else {
          console.log('[WebRTC] ICE gathering complete for', remoteUserId);
        }
      };

      pc.onconnectionstatechange = () => {
        console.log('[WebRTC] connection state', remoteUserId, ':', pc.connectionState);
        if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
          cleanupPeer(remoteUserId);
        }
      };

      pc.oniceconnectionstatechange = () => {
        console.log('[WebRTC] ICE connection state', remoteUserId, ':', pc.iceConnectionState);
      };

      peersRef.current.set(remoteUserId, pc);
      return pc;
    },
    [localStream, setRemoteStream]
  );

  const cleanupPeer = useCallback(
    (userId: string) => {
      const pc = peersRef.current.get(userId);
      if (pc) {
        pc.close();
        peersRef.current.delete(userId);
      }
      removeRemoteStream(userId);
    },
    [removeRemoteStream]
  );

  const cleanupAll = useCallback(() => {
    peersRef.current.forEach((pc) => pc.close());
    peersRef.current.clear();
  }, []);

  // Create and send offer to a new peer (only if our userId is smaller — one side initiates per pair)
  const createOffer = useCallback(
    async (remoteUserId: string) => {
      if (currentUserIdRef.current && remoteUserId < currentUserIdRef.current) {
        console.log('[WebRTC] remote userId is smaller, skipping offer (they should initiate)');
        return;
      }
      // If a PC already exists for this peer, close it before creating a fresh one
      const existingPc = peersRef.current.get(remoteUserId);
      if (existingPc) {
        console.log('[WebRTC] closing existing PC for', remoteUserId, 'to start fresh');
        existingPc.close();
        peersRef.current.delete(remoteUserId);
        removeRemoteStream(remoteUserId);
      }
      console.log('[WebRTC] creating offer to:', remoteUserId);
      const pc = createPeerConnection(remoteUserId);
      try {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        sendOffer(remoteUserId, offer);
      } catch (e) {
        console.error('Failed to create offer:', e);
      }
    },
    [createPeerConnection, removeRemoteStream]
  );

  // Handle incoming offer
  const handleOffer = useCallback(
    async (from: string, offer: RTCSessionDescriptionInit) => {
      const existingPc = peersRef.current.get(from);
      // If we have an existing PC in stable state (we initiated before), close it and start fresh
      // This handles the case where both sides tried to initiate simultaneously
      if (existingPc && existingPc.signalingState === 'stable') {
        console.log('[WebRTC] closing existing stable PC for', from, 'to handle incoming offer');
        existingPc.close();
        peersRef.current.delete(from);
        removeRemoteStream(from);
      }

      let pc = peersRef.current.get(from);
      if (!pc) {
        pc = createPeerConnection(from);
      }

      // If we already have a remote description, skip
      if (pc.signalingState !== 'have-remote-offer') {
        try {
          await pc.setRemoteDescription(new RTCSessionDescription(offer));
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          sendAnswer(from, answer);
        } catch (e) {
          console.error('Failed to handle offer:', e);
        }
      } else {
        console.log('[WebRTC] already have remote offer from', from, '— skipping duplicate');
      }
    },
    [createPeerConnection, removeRemoteStream]
  );

  // Handle incoming answer
  const handleAnswer = useCallback(async (from: string, answer: RTCSessionDescriptionInit) => {
    const pc = peersRef.current.get(from);
    if (pc) {
      // Only process if we have a pending offer (pranswer or offer)
      if (pc.signalingState === 'have-local-offer') {
        try {
          await pc.setRemoteDescription(new RTCSessionDescription(answer));
        } catch (e) {
          console.error('Failed to handle answer:', e);
        }
      } else {
        console.log('[WebRTC] not in have-local-offer state, skipping answer from', from, 'state:', pc.signalingState);
      }
    }
  }, []);

  // Handle incoming ICE candidate
  const handleIceCandidate = useCallback(async (from: string, candidate: RTCIceCandidateInit) => {
    console.log('[WebRTC] ICE candidate received from', from, ':', candidate.type, candidate.protocol, candidatefoundation);
    const pc = peersRef.current.get(from);
    if (pc) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (e) {
        console.error('[WebRTC] Failed to add ICE candidate:', e);
      }
    } else {
      console.log('[WebRTC] No PC found for', from, '— cannot add ICE candidate');
    }
  }, []);

  // Listen for signaling events
  useEffect(() => {
    const socket = getSocket();

    const handleSignal = async (message: { type: string; from: string; data: any }) => {
      switch (message.type) {
        case 'offer':
          await handleOffer(message.from, message.data);
          break;
        case 'answer':
          await handleAnswer(message.from, message.data);
          break;
        case 'ice-candidate':
          await handleIceCandidate(message.from, message.data);
          break;
      }
    };

    // A new remote user joined — create offer to them (mesh model: only smaller userId initiates)
    const handleUserJoined = ({ userId }: { userId: string; isLocal?: boolean }) => {
      console.log('[WebRTC] user-joined event from:', userId);
      // Only initiate if our userId is smaller (deterministic: one side initiates per pair)
      if (currentUserIdRef.current && currentUserIdRef.current < userId) {
        console.log('[WebRTC] our userId is smaller, creating offer to:', userId);
        createOffer(userId);
      } else {
        console.log('[WebRTC] our userId is larger, waiting for their offer');
      }
    };

    const handleRoomJoined = async (data: { userId: string; participants: any[] }) => {
      console.log('[WebRTC] room-joined event, our userId:', data.userId, 'participants:', data.participants);
      // Only initiate offers to participants with larger userId (skip those with smaller userId — they'll initiate to us)
      for (const participant of data.participants) {
        if (data.userId < participant.userId) {
          console.log('[WebRTC] our userId is smaller, creating offer to:', participant.userId);
          await createOffer(participant.userId);
        } else {
          console.log('[WebRTC] our userId is larger, waiting for offer from:', participant.userId);
        }
      }
    };

    const handleUserLeft = ({ userId }: { userId: string }) => {
      cleanupPeer(userId);
    };

    socket.on('signal', handleSignal);
    socket.on('user-joined', handleUserJoined);
    socket.on('room-joined', handleRoomJoined);
    socket.on('user-left', handleUserLeft);

    return () => {
      socket.off('signal', handleSignal);
      socket.off('user-joined', handleUserJoined);
      socket.off('room-joined', handleRoomJoined);
      socket.off('user-left', handleUserLeft);
    };
  }, [handleOffer, handleAnswer, handleIceCandidate, createOffer, cleanupPeer]);

  // Replace video track (for screen sharing)
  const replaceVideoTrack = useCallback((newTrack: MediaStreamTrack) => {
    peersRef.current.forEach((pc) => {
      const sender = pc.getSenders().find((s) => s.track?.kind === 'video');
      if (sender) {
        sender.replaceTrack(newTrack);
      }
    });
  }, []);

  return { createOffer, cleanupAll, replaceVideoTrack };
}
