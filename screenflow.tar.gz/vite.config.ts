import path from 'path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  root: 'src',
  base: '/meet/',
  publicDir: '../public',
  build: {
    outDir: '../dist',
    emptyOutDir: true,
  },
  server: {
    port: 3000,
    host: '0.0.0.0',
    proxy: {
      '/meet/api': {
        target: 'http://localhost:4000',
        rewrite: (path) => path.replace(/^\/meet/, ''),
      },
      '/meet/socket.io': {
        target: 'http://localhost:4000',
        ws: true,
        rewrite: (path) => path.replace(/^\/meet/, ''),
      },
    },
  },
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
    },
  },
});
