import dotenv from 'dotenv';
dotenv.config();

const nodeEnv = process.env.NODE_ENV || 'development';
const jwtSecret = process.env.JWT_SECRET || '';

// Fail fast in production if JWT_SECRET is missing
if (nodeEnv === 'production' && !jwtSecret) {
  console.error('FATAL: JWT_SECRET environment variable is required in production');
  process.exit(1);
}

export const serverConfig = {
  port: parseInt(process.env.PORT || '4000'),
  nodeEnv,
  jwtSecret: jwtSecret || 'dev-secret-change-in-production',
  openrouterApiKey: process.env.OPENROUTER_API_KEY || '',
  aiModel: process.env.AI_MODEL || 'meta-llama/llama-3.1-8b-instruct:free',
  corsOrigin: process.env.CORS_ORIGIN || '',
  maxParticipants: 4,
  maxWhiteboardStrokes: 500,
};
